const mongoose = require("mongoose")
const MarkSchema = new mongoose.Schema({
    email:{type:String,required:true},
    name:{type:String,required:true},
    topic:{type:String,required:true},
    score:{type:Number,required:true}
})

const MarkModel = mongoose.model("marks", MarkSchema)

module.exports =MarkModel;        