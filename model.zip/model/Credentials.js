const mongoose = require("mongoose")

const CredentialSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    phone: String
})

const CredentialModel = mongoose.model("credentials", CredentialSchema)

module.exports = CredentialModel