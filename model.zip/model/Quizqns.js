const mongoose = require("mongoose")
const QuestionSchema=new mongoose.Schema({
    qn:{type:String,required:true},
    opt:{type:[String],required:true},
    ans:{type:Number,required:true}
})
const QuizSchema = new mongoose.Schema({
    topic:{type:String,required:true},
    questions:[QuestionSchema]
})

const QuizModel = mongoose.model("questions", QuizSchema)

module.exports = QuizModel