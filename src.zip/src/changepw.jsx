import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
export default function Changepw(){
    const {state}=useLocation();
    console.log("state",state)
    const {name,email,password}=state;
    console.log("NaEmOP",name,email,password);
    const[entered,setEntered]=useState('');
    const[newpassword,setNewpassword]=useState('');
    const navigate=useNavigate();
    function handlePwChange(){
        if(entered===password){
            axios.post("https://localhost:3001/changepw",{email,newpassword})
            .then(result => {console.log(result)
                window.alert(result.data.message);
                navigate('/user')
        })
        .catch(err=> console.log(err))
    }
    else{window.alert("enter correct old password")}
        }
    return(
        <>
        <label htmlFor="password" className='password'>Password:</label>
          <input 
            type="password" 
            id="password"
            onChange={(e)=>{setEntered(e.target.value)}}
            />
            <label htmlFor="newpassword" className='password'>New Password:</label>
            <input 
                type="password" 
                id="newpassword"
                onChange={(e)=>{setNewpassword(e.target.value)}}
            />
            <button onClick={handlePwChange}> Change password</button>
        </>
    )
}
            
