import React, {useState,useEffect} from "react";
import './cssfiles/Quiz.css';
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

function Quiz() {
    const [currentQuestion, setCurrentQuestion]=useState(0);
    const [score, setscore]=useState(0);
    const [showfinalResults, setFinalResults]=useState(false);
    const navigate=useNavigate();
    const {state}=useLocation();
    const{ topic, email,name, questions }=state;
    const[quizz,setQuizz]=useState({});
    console.log("STATE",state)
    console.log("ques in quiz",questions)
    console.log("topic in quiz",topic)
  const optionClicked=(index,ans)=>{
    if(index===ans){
      setscore(score+1);
    }

  if(currentQuestion+1<questions.length){
    setCurrentQuestion(currentQuestion+1);
  }else{
    setFinalResults(true);
    

  }
  }
  if (questions.length === 0) {
      return <p>Loading...</p>;
    }
  

  return(
    <div class="App">
      <h1>{topic}</h1>

      <h2>Current score: {score}</h2>

      {showfinalResults?(
        <div class="final-results">
          <h1>Final Result</h1>
          <h2>You scored {score} out of {questions.length} correct - ({(score/questions.length)*100}%)</h2>
          <div>
            <button className="quizBut"onClick={()=>{
              navigate("/user", { state: { topic,email,name,questions} })
              console.log("qn,lg",questions.length,score)
              axios.post("http://localhost:3001/addmark",{email,name,topic,score})
              .then(result => {console.log(result.data.message)})
              .catch(err=> console.log(err))
            }}>GO BACK</button>
          </div>
        </div>
        
        
        

      ):(
        <div class="question-card">
        <h2>Question {currentQuestion+1} out of {questions.length}</h2>
        <h3 class="question-text">{questions[currentQuestion].qn}</h3>

        <ul class="optionList">
          {questions[currentQuestion].opt.map((option,index)=>{
            return(
              <li onClick={()=>optionClicked(index,questions[currentQuestion].ans)} key={index}>{option}</li>
            );
            

          })}
        </ul>

      </div>

      )}
    </div>
  );
}
export default Quiz;