import "./cssfiles/Register.css"
import { Link,useNavigate } from "react-router-dom"
import { useState } from "react"
import axios from 'axios'
export default function Register(){
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [phone, setPhone] = useState('')
    const navigate=useNavigate();
    function handleSubmit(e){
        e.preventDefault()
        axios.post('http://localhost:3001/register', {name, email, password, phone})
        .then(result => {console.log(result)
                navigate('/login')
        })
        .catch(err=> console.log(err))
    }
    return(
        <>
        <div id="register">
            <h2>Register</h2>
            <form onSubmit={handleSubmit} >
            <label htmlFor="name">Name:</label><br/>
            <input type="text" id="name" name="name" className='input-field' onChange={(e)=>{setName(e.target.value)}}required/><br/><br/>
            
            <label htmlFor="email">Email:</label><br/>
            <input type="email" id="email" name="email" className='input-field'onChange={(e)=>{setEmail(e.target.value)}} required/><br/><br/>
            
            <label htmlFor="password">Password:</label><br/>
            <input type="password" id="password" name="password" className='input-field'onChange={(e)=>{setPassword(e.target.value)}} required/><br/><br/>

            <label htmlFor="phone">Phone Number:</label><br/>
            <input type="tel" id="phone" name="phone" maxlength="10" className='input-field'onChange={(e)=>{setPhone(e.target.value)}} required/><br/><br/>
            
            <input type="submit" value="Register" className="register-button"/>
            </form>
        </div>
        </>
    )
}