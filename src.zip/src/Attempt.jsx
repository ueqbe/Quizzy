import React, {useState} from "react";
import './cssfiles/Quiz.css';


function Attempt() {
  const [currentQuestion, setCurrentQuestion]=useState(0);
 
  const [Score, setScore]=useState(0);
  const [showfinalResults, setFinalResults]=useState(false);
 

  const questions=[
    {
      text: "Which of the following replica sets vote in the election of a primary replica set?",
      options: [
        {id: 0, text: " Secondary", isCorrect: false},
        {id: 1, text: " Hidden", isCorrect: false},
        {id: 2, text: " Delayed", isCorrect: false},
        {id: 3, text: " All of the above", isCorrect: true},
      ],
    },
    {
      text: " Which of the following commands can cause the database to be locked?",
      options: [
        {id: 0, text: " Issuing a query", isCorrect: false},
        {id: 1, text: " Inserting data", isCorrect: false},
        {id: 2, text: " Map-reduce", isCorrect: false},
        {id: 3, text: " All of the above", isCorrect: true},
      ],
    },
    {
      text: " Can you assign a anonymous function to a variable?",
      options: [
        {id: 0, text: "True", isCorrect: true},
        {id: 1, text: "False", isCorrect: false},
      ],
    },
    {
      text: "Which built-in method sorts the elements of an array?",
      options: [
        {id: 0, text: "changeOrder(order)", isCorrect: false},
        {id: 1, text: " order()", isCorrect: false},
        {id: 2, text: "sort()", isCorrect: true},
        {id: 3, text: " None of the above", isCorrect: true},
      ],
    },
    {
      text: "Which of the following type of variable is visible only within a function where it is defined?",
      options: [
        {id: 0, text: "global variable", isCorrect: false},
        {id: 1, text: "local variable", isCorrect: true},
        {id: 2, text: " Both of the above.", isCorrect: true},
        {id: 3, text: " None of the above", isCorrect: true},
      ],
    },
  ];

const optionClicked=(isCorrect)=>{
  if(isCorrect){
    setScore(Score+1);
  }

  if(currentQuestion+1<questions.length){
    setCurrentQuestion(currentQuestion+1);
  }else{
    setFinalResults(true);
  }

  
}

const restartQuiz=()=>{
  setScore(0);
  setCurrentQuestion(0);
  setFinalResults(0);
}

  return(
    <div class="App">
      <h1>IP Quiz</h1>

      <h2>Current Score: {Score}</h2>

      {showfinalResults?(
        <div class="final-results">
          <h1>Final Result</h1>
          <h2>{Score} out of {questions.length} correct - ({(Score/questions.length)*100}%)</h2>
  
          <button onClick={()=> restartQuiz()}>Restart Quiz</button>  
  
        </div>

      ):(
        <div class="question-card">
        <h2>Question {currentQuestion+1} out of {questions.length}</h2>
        <h3 class="question-text">{questions[currentQuestion].text}</h3>

        <ul class="optionList">
          {questions[currentQuestion].options.map((option)=>{
            return(
              <li onClick={()=>optionClicked(option.isCorrect)} key={option.id}>{option.text}</li>
            );
            

          })}
        </ul>

      </div>

      )}





    </div>
  );
}

export default Attempt;