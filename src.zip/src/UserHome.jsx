import React, { useState,useEffect } from 'react'; // Import useState from 'react'
import "./cssfiles/UserHome.css";
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
//<button className='but'onClick={()=>{
//    navigate('/changepw',{state:{name,email,password}})
//}}>Change password</button>
// Rename the function to start with an uppercase letter
export default function UserHome() {
   // const [count, setCount] = useState(0);
   const [attempt,setAttempt] = useState(0);
   const {state:s1}=useLocation();
   console.log("S1",s1);
   const {name,email,password}=s1;
   console.log("NEP",name,email,password)
   const [quizzes, setQuizzes] = useState([]);
   const[marks,setMarks]=useState([]);
   const[marksVisible,setMarksVisible]=useState(false);
    const navigate = useNavigate();
    useEffect(() => {
        axios.get('http://localhost:3001/quizes')
            .then(response => {
                //console.log(response.data);
                setQuizzes(response.data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }, []);
    console.log("QUIZZZZ",quizzes )
    const attemptQuiz = (topic, questions) => {
        axios.post('http://localhost:3001/check-quiz-attempt', { email, topic })
            .then(response => {
                const { attempted } = response.data;
                if (attempted) {
                    alert('You have already attempted this quiz.');
                } else {
                    navigate('/quiz', { state: { topic,email,name,questions} });
                }
            })
            .catch(error => {
                console.error('Error checking quiz attempt:', error);
                alert('Error checking quiz attempt. Please try again later.');
            });
    };
    const GetMarks=() => {
        axios.post('http://localhost:3001/get-marks-user', { email })
            .then(response => {
                setMarks(response.data);
                setMarksVisible(true);
                console.log("MARKS",marks)
            })
            .catch(error => {
                console.error('Error fetching marks:', error);
                setMarksVisible(false);
            });
    
    }
    const MarksDisplay=()=>{
        return(
            <div className="marks"style={{ marginBottom: '20px', display: marksVisible ? 'block' : 'none' }}>
                <h2>MY MARKS</h2>
                <table>
                    <thead>
                    <tr>
                        <th>TOPIC</th>
                        <th>MARKS</th>
                    </tr>
                    </thead>
                    <tbody>
                        {
                            marks.map((mark, index) => (
                                <tr key={index}>
                                    <td>{mark.topic}</td>
                                    <td>{mark.score}</td>
                                </tr>))}
                    </tbody>
                   
                </table>
            </div>
        )
    }
    return (
        <div className="container">
            <div className="left">
                <div className="WrapLeft">
                <h1 style={{color:'#f28185'}}>WELCOME {name}!</h1>
                <button className="quizBut"onClick={()=>{navigate('/')}}>LOGOUT</button>
                <br></br>
                
                <p></p>
                </div>
            </div>
            <div className="right">
                {quizzes.map((quiz, index) => (
                    <div className="quizComp" key={index}>
                        <div className='quizNameComp'>
                            <h3 style={{ color: '#f28185' }}>{quiz.topic}</h3>
                        </div>
                        <div className='quizButDiv'>
                                <button className='quizBut' onClick={() => attemptQuiz(quiz.topic, quiz.questions)}>Attempt Quiz</button>
                        </div>
                        
                    </div>
                ))}
                <button className='quizBut' style={{width:150}} onClick={() =>GetMarks()}>Get Marks</button>
                 <MarksDisplay/>
            </div>
       </div>

    );
}
