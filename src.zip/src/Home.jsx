import {Link} from 'react-router-dom';
import "./cssfiles/Home.css"
export default function Home(){
    return(
        <>
        <div id="background">
            <div id="centered">
                <h1>Quizizzz!</h1>
                <h1>Play to learn!</h1>
            </div>
            <div id="buttonPanel">
            <button id ="button">
                <Link to="/register" style={{ textDecoration: 'none', color: '#f28185' }}>Get started for Free</Link>
            </button>
            <button id="button" class="b2">
                <Link to="/login" style={{textDecoration: 'none', color: '#f28185' }}>Already have an account?</Link>
            </button>
            </div>
        </div>
        </>
    )
}
