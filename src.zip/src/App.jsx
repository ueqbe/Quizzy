import Home from "./Home.jsx"; 
import Login from "./Login.jsx"; 
import Register from "./Register.jsx"; 
import UserHome from "./UserHome.jsx";
import AdminHome from "./AdminHome.jsx";
import Changepw from "./changepw.jsx";
import Quiz from "./Quiz.jsx"
import { BrowserRouter, Route,Routes } from 'react-router-dom';
export default function App(){
    return(
        <BrowserRouter>
        <Routes>
            <Route path="/" element={<Home/>}></Route>
            <Route path="/home" element={<Home/>}></Route>
            <Route path="/login" element={<Login/>}></Route>
            <Route path="/register" element={<Register/>}></Route>
            <Route path="/user" element={<UserHome/>}></Route>
            <Route path="/admin" element={<AdminHome/>}></Route>
            <Route path="/changepw" element={<Changepw/>}></Route>
            <Route path="/quiz" element={<Quiz/>}></Route>
        </Routes>
        </BrowserRouter>
    )
}