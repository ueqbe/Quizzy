import {useState} from 'react';
import "./cssfiles/Login.css";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
const Login = () =>{
  const[email, setEmail]=useState('');
  const[password, setPassword]=useState('');
  const navigate=useNavigate();

  const handleEmailChange=(e)=>{
    setEmail(e.target.value);
  };

  const handlePasswordChange=(e)=>{
    setPassword(e.target.value);
  };

  const handleSubmit=(e)=>{
    e.preventDefault();

    //console.log('Email:',email);
    //console.log('Password', password);

    setEmail('');
    setPassword('');
    axios.post('http://localhost:3001/login', {email, password})
        .then(result => {
            console.log(result)
            if (result.data.message === "Success"){
              if(email==="admin@gmail.com"){
                navigate('/admin', { state: { name: result.data.name, email: result.data.email,password:result.data.password} })
              }
              else{
                navigate('/user', { state: { name: result.data.name, email: result.data.email,password:result.data.password} })
              }
            }
            else if (result.data.message === "The password is incorrect"){
                window.alert("Invalid Credentials. Try Again...")
                navigate('/login')
            }
            else{
                window.alert("No such user exists. Create one...")
                navigate('/register')
            }
        })
        .catch(err=>{ console.log(err)})
    
  }

  return(
    <div >
      <div className='login'>
          <h2>
            LOGIN
          </h2>
          <form onSubmit={handleSubmit}>
            <div className='form-group'>
              <label htmlFor="email" className='email'>Email:</label>
              <input 
                type="email" 
                id="email"
                value={email}
                onChange={handleEmailChange}
                required
                className='input-field'
              />

            </div>
            <div className='form-group'>
              <label htmlFor="password" className='password'>Password:</label>
              <input 
                type="password" 
                id="password"
                value={password}
                onChange={handlePasswordChange}
                required
                className='input-field'
              />
            </div>
            <button type='submit' className='login-button'>Login</button>
          </form>
      </div>
    </div>
  );
  };

export default Login;