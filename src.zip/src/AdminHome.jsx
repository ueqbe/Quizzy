import React, { useState,useEffect } from 'react'; // Import useState from 'react'
import "./cssfiles/AdminHome.css";
import axios from 'axios';
import { useNavigate,useLocation } from 'react-router-dom';
// Rename the function to start with an uppercase letter
export default function AdminHome() {
   // const [count, setCount] = useState(0);
   const[marks,setMarks]=useState([]);
   const[marksVisible,setMarksVisible]=useState(false);
    const navigate = useNavigate();
    const{name,email,password}=useLocation();
   const [quizzes, setQuizzes] = useState([]);
   const[selectedTopic,setSelectedTopic]=useState(null);
    useEffect(() => {
        axios.get('http://localhost:3001/quizes')
            .then(response => {
                //console.log(response.data);
                setQuizzes(response.data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }, []);
    console.log("QUIZZZZ",quizzes )
    const GetMarks=(topic) => {
        setSelectedTopic(topic)
        axios.post('http://localhost:3001/get-marks-admin', { topic })
            .then(response => {
                setMarks(response.data);
                setMarksVisible(true);
                console.log("MARKS",marks)
            })
            .catch(error => {
                console.error('Error fetching marks:', error);
                setMarksVisible(false);
            });
            
            
    }
   const MarksDisplay=()=>{
    return(
        <div className="marks"style={{ marginBottom: '20px', display: marksVisible ? 'block' : 'none' }}>
            <h2>{selectedTopic} MARKS</h2>
            <table>
                <thead>
                <tr>
                    <th>USERNAME</th>
                    <th>MARKS</th>
                </tr>
                </thead>
                <tbody>
                    {
                        marks.map((mark, index) => (
                            <tr key={index}>
                                <td>{mark.name}</td>
                                <td>{mark.score}</td>
                            </tr>))}
                </tbody>
               
            </table>
        </div>
    )
}
return (
    <div className="container">
        <div className="left">
            <div className="WrapLeft">
            <h1 style={{color:'#f28185'}}>WELCOME ADMIN!</h1>
            <button className="quizBut"onClick={()=>{navigate('/')}}>LOGOUT</button>
            <br></br>
            
            <p></p>
            </div>
        </div>
        <div className="right">
            {quizzes.map((quiz, index) => (
                <div className="quizComp" key={index}>
                    <div className='quizNameComp'>
                        <h3 style={{ color: '#f28185' }}>{quiz.topic}</h3>
                    </div>
                    <div className='quizButDiv'>
                            <button className='quizBut' onClick={() => GetMarks(quiz.topic)}>GETMARKS</button>
                    </div>
                    
                </div>
            ))}
             <MarksDisplay/>
        </div>
   </div>

);
}
